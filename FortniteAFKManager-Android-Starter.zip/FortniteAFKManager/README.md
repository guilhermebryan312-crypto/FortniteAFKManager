# Fortnite AFK Manager — Android starter

Protótipo inicial em Kotlin + Jetpack Compose, preparado como projeto Android Studio.

## O que já existe
- Dashboard inicial.
- Navegação por cinco áreas.
- Configuração visual de limite de partidas, temporizador e intervalo.
- Catálogo inicial com 18 nomes únicos de recompensas.
- Tela de configuração de Discord (ainda sem envio real).
- Serviço de overlay demonstrativo, ativado manualmente.
- Tema escuro azul/preto.

## Limites importantes desta versão
Este starter **não é um APK pronto** e ainda não implementa:
- Automação de toques, movimentos, entrada ou saída de partidas no Fortnite.
- Evasão de detecção AFK ou anticheat.
- Leitura automática do estado do squad a partir do jogo.
- Captura automática da tela do jogo / OCR em tempo real.
- Envio real de Webhook.
- Histórico persistente com banco de dados.

O Android não fornece automaticamente os dados internos da partida. O monitoramento do squad e recompensas precisa de uma fonte visual permitida, confirmação do usuário ou integração oficialmente disponível. Estados não confirmados devem aparecer como "Desconhecido".

## Como abrir
1. Instale o Android Studio em um computador.
2. Extraia o ZIP.
3. Abra a pasta `FortniteAFKManager`.
4. Aguarde a sincronização do Gradle.
5. Execute em um emulador ou celular Android.

Requisitos: Android Studio recente, JDK 17 e SDK Android 35.
